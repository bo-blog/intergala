var app = require('scripts/app');

app.drawIt();
