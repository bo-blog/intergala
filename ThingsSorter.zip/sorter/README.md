Where is it? - A quick reminder where those small things are stored.

V1.0.0